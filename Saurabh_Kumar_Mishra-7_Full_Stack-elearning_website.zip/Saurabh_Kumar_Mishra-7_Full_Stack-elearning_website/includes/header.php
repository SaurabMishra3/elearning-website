<?php
//start session
@session_start();

//number of items in the shopping cart
$count=0;

//retrieve the cart content
if ( isset ( $_SESSION['cart'] ) ){
	$cart = $_SESSION['cart'];

	if  ( $cart ) {
		$items = explode(',', $cart);
		$count = count($items);
	}
}

//check to see if a user if logged in
$login = '';
$name = '';
$role = 0;

if (isset($_SESSION['login'])){
	$login = $_SESSION['login'];
}

if (isset($_SESSION['name'])) {
	$name = $_SESSION['name'];
}

if (isset($_SESSION['role'])){
	$role = $_SESSION['role'];
}

if (isset($_SESSION['id'])) {
	$session_id = $_SESSION['id'];
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $page_title; ?></title>
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">  <link rel="stylesheet" href="assets/css/main.css"/>
 <title>Learn with Saurabh</title>
 </head>
<body>
  
 <div class="header">
  <a href="index.php" class="logo"> <img src="assets/img/logo.png" style="width: 76px"></a>
  <div class="header-left">
    <a  href="about.php">About Us</a>
    <a href="tutorial.php">Tutorial</a>
    <a href="reference.php">Reference</a>
    <a href="exercise.php">Exercise</a>
    <a href="subjects.php">Subjects List</a>
    
  </div>
  <div class="login-right">
      <a class="active" href="register.php">Sign Up!</a>

      

  <a class="active" href="login.php">Log in</a>
</div>
</div>
