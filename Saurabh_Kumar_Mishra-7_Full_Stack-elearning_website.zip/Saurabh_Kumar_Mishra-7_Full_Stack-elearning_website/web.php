<?php
  require_once("includes/header.php");  
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		web development
	</title>
</head>
<body>
	
<h1>What is HTML?</h1>
<ul>
<p>HTML stands for Hyper Text Markup Language<br>
HTML is the standard markup language for creating Web pages<br>
HTML describes the structure of a Web page<br>
HTML consists of a series of elements<br>
HTML elements tell the browser how to display the content<br>
HTML elements label pieces of content such as "this is a heading", "this is a paragraph", "this is a link", etc<br></p></ul>
</body>
</html>
<?
	include_once('includes/footer.php')
?>