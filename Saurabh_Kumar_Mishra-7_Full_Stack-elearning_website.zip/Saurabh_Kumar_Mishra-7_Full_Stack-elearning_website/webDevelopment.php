<?php
  require_once("includes/header.php");  
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		web development
	</title>
</head>
<body>
	
<h1>What is HTML?</h1>
<ul>
<p>HTML stands for Hyper Text Markup Language<br>
HTML is the standard markup language for creating Web pages<br>
HTML describes the structure of a Web page<br>
HTML consists of a series of elements<br>
HTML elements tell the browser how to display the content<br>
HTML elements label pieces of content such as "this is a heading", "this is a paragraph", "this is a link", etc<br></p>

</ul>
<h2>What is an HTML Element?</h2>
<p>An HTML element is defined by a start tag, some content, and an end tag:

<tagname>Content goes here...</tagname>
The HTML element is everything from the start tag to the end tag:

<h1>My First Heading</h1>
<p>My first paragraph.</p></p><br><br>
<h2>Learn HTML Using Notepad or TextEdit</h2>
<p>Web pages can be created and modified by using professional HTML editors.<br>

However, for learning HTML we recommend a simple text editor like Notepad (PC) or TextEdit (Mac).<br>

We believe in that using a simple text editor is a good way to learn HTML.<br>

Follow the steps below to create your first web page with Notepad or TextEdit.<br>
</p>

</body>
</html>
<?
include_once("subjects.php");
	include_once('includes/footer.php')
?>