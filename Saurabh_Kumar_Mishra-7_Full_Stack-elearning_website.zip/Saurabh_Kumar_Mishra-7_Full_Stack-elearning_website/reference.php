<?php 
require_once("includes/header.php");  
?>
<<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Reference</title>
</head>
<body>
    <h1>What is Lorem Ipsum?</h1>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br> Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.<br> It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.<br> It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br>
</p>

</body>
</html>

<?php
require_once("includes/footer.php");
?>